#pragma once
#include "Citizen.h"
class VotersBook 
{
	public:
	private:
		Citizen* citizenLs;
};