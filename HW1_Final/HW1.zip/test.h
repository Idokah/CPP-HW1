//
// Created by Romi Erez on 30/11/2020.
//

#ifndef Q1_TEST_H
#define Q1_TEST_H


class test {

};


#endif //Q1_TEST_H
